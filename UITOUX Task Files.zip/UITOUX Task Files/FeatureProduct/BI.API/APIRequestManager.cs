﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;    

namespace BI.API
{ 
    public static class APIRequestManager
    {
         
        public static T POST<T>(string RequestURL, object model)
        { 
            var APIURL = null;
			
			// We can get API URL from APPSetting or Database
			//APIURL = System.Configuration.ConfigurationManager.AppSettings["DefaultConnection"]; 
			
			APIURL = "https://APIHostURL"+ "/api/"; 
			
            HttpClient hc = new HttpClient();
            var myContent = JsonConvert.SerializeObject(model);
            var stringContent = new StringContent(myContent, System.Text.Encoding.UTF8, "application/json");

            var response = hc.PostAsync(System.IO.Path.Combine(APIURL, RequestURL), stringContent).Result;
            if (response.IsSuccessStatusCode)
            {
                string content = response.Content.ReadAsStringAsync().Result;
                 
                    var Data = JsonConvert.DeserializeObject<T>((JObject.Parse(content).SelectToken("Data").ToString()));
                    return Data;
                
            }
            else
                return (T)Activator.CreateInstance(typeof(T));
        }
 
    }
}