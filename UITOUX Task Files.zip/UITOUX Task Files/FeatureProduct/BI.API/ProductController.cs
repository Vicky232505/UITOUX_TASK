using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Http; 
using BI.Model; 
using System.Threading.Tasks; 

namespace BI.API
{
	[Authorized]
    [RoutePrefix("api/Product")]
    public class ProductController : BaseController
    {
        public long _UserId = CookieManager.UserId; // We can get userid of user those who loged in portal, if not loged in by any user it will have value as 0
        public string _langCode = CookieManager.LangCode; // We can get Language seleted dropdown key in portal 
	
		[Route("Get/FeatureProductList")]
        [HttpPost]
        public async Task<IHttpActionResult> GetFeatureProductList(FeatureProductListSearchModel featureProductListParam)
        {
			
			featureProductListParam.UserId = _UserId;
			featureProductListParam.LangCode = _langCode;
			
			 
			// Note : For DB connection, I can able to handle ADO, Entity and Dapper. Here I used ADO.
            FeatureProductListViewModel Data = DBRequest.GetFeatureProductList(featureProductListParam); 
            return Ok(Data);

        }
	}
	
}