﻿using BI.Model; 
using Newtonsoft.Json;
using System.Data.SqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Threading.Tasks;

namespace BI.API
{
    public static class DBRequest
    { 

        public static FeatureProductListViewModel GetFeatureProductList(FeatureProductListSearchModel parms)
        { 
            FeatureProductListViewModel Result = new FeatureProductListViewModel();
			
            //using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["DefaultConnection"]))
			using (SqlConnection con = new SqlConnection("data source=DBServerIP;Initial Catalog=DBName;Integrated Security=False;user id=sa;password=DBPassword"))
            {
                using (SqlCommand cmd = new SqlCommand(DBConstant.SPGetFeatureProductList, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@UserId", SqlDbType.BigInt).Value = parms.UserId;
                    cmd.Parameters.Add("@LangCode", SqlDbType.VarChar).Value = parms.LangCode;
                    cmd.Parameters.Add("@FeatureProductListTypeId", SqlDbType.BigInt).Value =  parms.FeatureProductListTypeId; 
                    cmd.Parameters.Add("@PageSize", SqlDbType.Int).Value = parms.PageSize;
                    cmd.Parameters.Add("@PageNumber", SqlDbType.Int).Value = parms.PageNumber; 
                    cmd.Parameters.Add("@SortColumn", SqlDbType.VarChar).Value = parms.SortColumn;
                    cmd.Parameters.Add("@SortOrder", SqlDbType.VarChar).Value = parms.SortOrder;
                    con.Open();

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            FeatureProductListModel _featureProductListModel = new FeatureProductListModel();
                            _featureProductListModel.RowNo = Convert.ToInt64(dr["RowNo"]);
                            _featureProductListModel.TotalCount = Convert.ToInt32(dr["TotalCount"]);
                            _featureProductListModel.FeatureProductDetailId = Convert.ToInt64(dr["FeatureProductDetailId"]); 
                            _featureProductListModel.ProductId = Convert.ToInt64(dr["ProductId"]); 
                            _featureProductListModel.ProductName = Convert.ToString(dr["ProductName"]);
                            _featureProductListModel.ProductImgPath = Convert.ToString(dr["ProductImgPath"]);
                            _featureProductListModel.ProductReviewRatting = Convert.ToDecimal(dr["ProductReviewRatting"]);
                            _featureProductListModel.ProductReviewCount = Convert.ToInt32(dr["ProductReviewCount"]); 
                            _featureProductListModel.Amount = Convert.ToDecimal(dr["Amount"]); 
                            _featureProductListModel.Currency = Convert.ToString(dr["Currency"]);
                            Result.LstCashback.Add(_featureProductListModel);
                        }
                    }
                }
                return Result;

            }
        }


 

    }
}
