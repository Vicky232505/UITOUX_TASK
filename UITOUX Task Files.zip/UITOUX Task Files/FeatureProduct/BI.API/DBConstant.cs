﻿using BI.Model; 
using Newtonsoft.Json;
using System.Data.SqlTypes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Threading.Tasks;

namespace BI.API
{
    public static class DBConstant
    { 

       public static readonly string SPGetFeatureProductList = "SP_GetFeatureProductList";

    }
}
