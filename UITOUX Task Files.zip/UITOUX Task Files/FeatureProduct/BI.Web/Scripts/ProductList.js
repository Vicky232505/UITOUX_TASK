var featureProductListPageNumber = 1; 
var featureProductListPageSize = 6; 

$(document).ready(function () {

    // default val declaration begin

    var featureProductListParam = {};
    featureProductListParam.UserId = 0;
    featureProductListParam.LangCode = "";
    featureProductListParam.featureProductListTypeId = 0;
    featureProductListParam.PageNumber = 1;
    featureProductListParam.PageSize = 6; 
    featureProductListParam.SortColumn = "StartDate";
    featureProductListParam.SortOrder = "Asc";
	
	getFeatureProductList();
}

function isNullOrEmpty(value){
	 
    return (value == null || value == undefined || value == "" || value.length == 0);	
	 
}

function getFeatureProductList() { 
    
	featureProductListParam.featureProductListTypeId = $("#FeatureProductListType option:selected").val(); 
	featureProductListParam.PageNumber = featureProductListPageNumber;
	featureProductListParam.featureProductListPageSize = featureProductListPageSize;
		
	if(isNullOrEmpty(featureProductListParam.featureProductListTypeId))
	{
		featureProductListParam.featureProductListTypeId = 0;
	}
	
	var Page
    $.ajax({
        type: "POST",
        url: "/Product/GetFeatureProductList",
        cache: false,
        data: featureProductListParam,
        "Content-Type": "application/json",
        datatype: 'application/json',
        beforeSend: function () { 
            $("#div_featureProductList").addClass("div-loader");   
        },
        complete: function () {
            $("#div_featureProductList").removeClass("div-loader");
        },
        success: function (data) {
            $("#div_featureProductList").append(data); // Main Page cshtml we load div partial view data
        },
        error: function(xhr, status, error) {   console.log('An error occurred: ' + error); } // we can handle as generic error track in project    
    });
}


$("#btnSideLoadNextPage").click(function () {
    featureProductListPageNumber = featureProductListPageNumber + 1;
    getFeatureProductList();
});


$("#btnSideLoadPrevPage").click(function () {
	if(featureProductListPageNumber > 1)
	{
		featureProductListPageNumber = featureProductListPageNumber - 1;
		getFeatureProductList();
	}
	else {
		
		alert("No Prev Page!!!");
	}
});


$('body').on('change', '#FeatureProductListType', function () {
	getFeatureProductList();
});