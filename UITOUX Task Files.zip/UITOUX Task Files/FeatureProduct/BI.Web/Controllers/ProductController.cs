using BI.Model;    
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace BI.Web.Controllers
{
	[SessionTimeout]
    [Authorized]
    public class ProductController : BaseController
    {

        [HttpPost]
        public ActionResult GetFeatureProductList(FeatureProductListSearchModel featureProductListParam)
        {
            var Data = BI.API.APIRequestManager.POST<FeatureProductListViewModel>("Product/Get/FeatureProductList",featureProductListParam);
            return View("~/Views/Product/_FeatureProductList.cshtml", Data);
        }
	}
}