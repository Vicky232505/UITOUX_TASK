﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text; 

namespace BI.Model
{ 

	public class FeatureProductListSearchModel
    { 
        public long 	UserId { get; set; } 
        public string 	LangCode { get; set; } 
        public long 	FeatureProductListTypeId { get; set; } 
        public int 		PageNumber { get; set; }
        public int 		PageSize { get; set; } 
        public string 	SortColumn { get; set; } 
        public string 	SortOrder { get; set; } 
    }

	public class FeatureProductListViewModel
    {  
        public List<FeatureProductListModel> Data { get; set; } 
    }

    public class FeatureProductListModel
    {
        public long 	RowNo { get; set; } 
        public int 		TotalCount { get; set; }
		public long 	FeatureProductDetailId { get; set; }
        public long 	ProductId { get; set; }
        public string 	ProductName { get; set; }
        public string 	ProductImgPath { get; set; }
        public decimal 	ProductReviewRatting { get; set; }
        public int 		ProductReviewCount { get; set; }
        public string 	Currency { get; set; } 
        public decimal 	Amount { get; set; } 
    } 
	

}
