-- Used to have language master data (show Language change dropdown in portal)
CREATE TABLE [dbo].[LanguageMaster] (
    [LanguageMasterId]           BIGINT         IDENTITY (1, 1) NOT NULL PRIMARY KEY,
    [LanguageCode]				 NVARCHAR(5)	NOT NULL,
    [LanguageName]				 NVARCHAR(50)	NOT NULL,
    [IsActive]					 BIT			NOT NULL,
    [InsertedBy]				 BIGINT,        
    [InsertedOn]				 DATETIME,      
    [UpdatedBy]					 BIGINT,        
    [UpdatedOn]					 DATETIME,      
    [DisplayOrder]				 INT,           
    [LanguageText]				 NVARCHAR(50), 
    [FlagCode]					 NVARCHAR(10),   
    CONSTRAINT [IX_LanguageMaster] UNIQUE NONCLUSTERED ([LanguageCode] ASC)
)
GO

-- Used to have resource key data as per language 
CREATE TABLE [dbo].[LanguageLibrary](
	[LanguageLibraryID]			BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Key]						NVARCHAR(100)	NOT NULL,
	[Value]						NVARCHAR(MAX)	NOT NULL,
	[LanguageCode]				NVARCHAR(5)		NOT NULL, 
	[InsertedBy]				BIGINT, 
	[InsertedOn]				DATETIME,
	[UpdatedBy]					BIGINT,
	[UpdatedOn]					DATETIME
)
GO

-- Used to have list for country master data
CREATE TABLE [dbo].[CountryMaster](
	[CountryMasterId]           BIGINT         IDENTITY (1, 1) NOT NULL PRIMARY KEY,
	[CountryCode]				NVARCHAR(10) NOT NULL,
	[CountryName]				NVARCHAR(100) NOT NULL,
	[ISDCode]					NVARCHAR(10),
	[ViewOrder]					BIGINT,
	[IsActive]					BIT,
	[DefaultLanguageMasterId]	BIGINT,
	CONSTRAINT [IX_LanguageMaster] UNIQUE NONCLUSTERED ([CountryCode] ASC)
)
GO

-- Used to have list for Currency master data
CREATE TABLE [dbo].[CurrencyMaster](
	[CurrencyMasterID]			BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[CurrencyName]				NVARCHAR(100)	NOT NULL,
	[CurrencySymbol]			NVARCHAR(10)	NOT NULL,
	[SupportedCountryId]		BIGINT			NOT NULL, 
	[ViewOrder]					BIGINT,
	[IsActive]					BIT,
	[InsertedBy]				BIGINT, 
	[InsertedOn]				DATETIME,
	[UpdatedBy]					BIGINT,
	[UpdatedOn]					DATETIME
)
GO

-- Used to have list for Vechile master data (We can specify Bike, Car, Van, Bus, Lorry etc)
CREATE TABLE [dbo].[VechileMaster](
	[VechileMasterID]			BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[VechileName]				NVARCHAR(100)	NOT NULL, 
	[ViewOrder]					BIGINT,
	[IsActive]					BIT,
	[InsertedBy]				BIGINT, 
	[InsertedOn]				DATETIME,
	[UpdatedBy]					BIGINT,
	[UpdatedOn]					DATETIME
)
GO

-- Used to have list for Company master data (We can specify BMW, Audi, Maruti, TATA, NEXA, Hundai, Honda etc)
CREATE TABLE [dbo].[CompanyMaster](
	[CompanyMasterID]			BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[CompanyName]				NVARCHAR(100)	NOT NULL, 
    [LogoImgUploadPath]			NVARCHAR(500),
	[StartDate]					DATETIME,										-- Used have company start date
	[CloseDate]					DATETIME,										-- Used have company end date if it closed or going to close
    [LogoImgUploadPath]			NVARCHAR(500),										
	[ViewOrder]					BIGINT,
	[IsActive]					BIT,
	[InsertedBy]				BIGINT, 
	[InsertedOn]				DATETIME,
	[UpdatedBy]					BIGINT,
	[UpdatedOn]					DATETIME
)
GO

-- Used to have list for Category master data (We can specify procduct comeunder which Category like Power Tools, Hand Tools, Wheel, Bake, Engine, AC, Dashboard etc)
CREATE TABLE [dbo].[CategoryMaster](
	[CategoryMasterID]			BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[CategoryName]				NVARCHAR(100)	NOT NULL, 
	[ViewOrder]					BIGINT,
	[IsActive]					BIT,
	[InsertedBy]				BIGINT, 
	[InsertedOn]				DATETIME,
	[UpdatedBy]					BIGINT,
	[UpdatedOn]					DATETIME
)
GO
