
-- Used to have all product detail
CREATE TABLE [dbo].[ProductDetail] (
    [ProductDetailId]           			BIGINT NOT NULL PRIMARY KEY,
    [ProductName]							NVARCHAR(500) NOT NULL,
    [ProductDescription]					NVARCHAR(MAX) NOT NULL,
	[CompanyId]								BIGINT,
	[SupportedCategoryId]					BIGINT,
	[SupportedVechileId]					BIGINT,
	[SupportedCountryId]					BIGINT,
	[Amount]								DECIMAL(18,2),
	[AmountCurrencyId]						BIGINT,
    [ImgUploadPath]							NVARCHAR(500),
    [ProductNameLanguageResourceKey]		NVARCHAR(500),		-- if needed we can use to fetch product name againt language seleted in portal using this key(can remove above ProductName colunm)
    [ProductDescriptionLanguageResourceKey]	NVARCHAR(500),		-- if needed we can use to fetch product description againt language seleted in portal using this key(can remove above ProductDescription colunm)
    [IsActive]								BIT,
    [InsertedBy]							BIGINT,        
    [InsertedOn]							DATETIME,      
    [UpdatedBy]								BIGINT,        
    [UpdatedOn]								DATETIME,     
)
GO

-- Used to have Review product detail
CREATE TABLE [dbo].[ReviewProductDetail] (
    [ReviewProductDetailId]		BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductDetailId]			BIGINT NOT NULL,
	[RatingCount]				INT NOT NULL,
	[Content]					NVARCHAR(MAX) NOT NULL,
	[ReviewedUserId]			BIGINT NOT NULL,		
	[IsActive]					BIT,
    [IsDeleted]					BIT,
    [InsertedBy]				BIGINT,        
    [InsertedOn]				DATETIME,      
    [UpdatedBy]					BIGINT,        
    [UpdatedOn]					DATETIME,     
)
GO

-- Used to have Review product summary 
-- it will reduce performance issue if we save while review submit for product otherwise for every product we need to arthimatic operation in select query. 
CREATE TABLE [dbo].[ReviewSummaryAgainstProduct] (
    [ReviewProductSummaryId]	BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductDetailId]			BIGINT NOT NULL,
	[ReviewerCount]				INT NOT NULL,	
	[RatingAvg]					DECIMAL NOT NULL, 
	[IsActive]					BIT,         
    [InsertedOn]				DATETIME, 
    [UpdatedOn]					DATETIME,     
)
GO

-- Used to have feature product detail
CREATE TABLE [dbo].[FeatureProductDetail] (
    [FeatureProductDetailId]	BIGINT NOT NULL PRIMARY KEY,
    [ProductDetailId]			BIGINT NOT NULL,
	[SupportedCategoryId]		BIGINT,
	[StartDate]					DATETIME,							-- use to have when we need to start display as feature product in portal				
	[EndDate]					DATETIME,							-- use to have when we need to end display as feature product in portal
    [IsActive]					BIT,
    [InsertedBy]				BIGINT,        
    [InsertedOn]				DATETIME,      
    [UpdatedBy]					BIGINT,        
    [UpdatedOn]					DATETIME,     
)
GO