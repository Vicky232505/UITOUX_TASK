CREATE PROC [dbo].[SP_GetFeatureProductList]              
(              
	   @UserID						BIGINT 
	 , @LangCode					NVARCHAR(5)
	 , @FeatureProductListTypeId	BIGINT 
	 , @PageNumber					INT
	 , @PageSize					INT         
	 , @SortOrder					NVARCHAR(30) = NULL            
	 , @SortColumn					NVARCHAR(30) = NULL        
            
)              
AS              
BEGIN    

		-- Instead of fetching whole table data and joining with other table. We can join exact data as per filer and joining that data alone. Mainly to avoid performance issue
		SELECT		ROW_NUMBER() OVER(ORDER BY	
												CASE WHEN(@SortColumn = 'StartDate' AND @SortOrder = 'ASC')		THEN  [FeatureProductDetail].[StartDate] END ASC,                      
												CASE WHEN(@SortColumn = 'StartDate' AND @SortOrder = 'DESC')	THEN  [FeatureProductDetail].[StartDate] END DESC
									) AS [RowNo]
					,COUNT(1) OVER() TotalCount 
					,[FeatureProductDetail].[FeatureProductDetailId]
					,[FeatureProductDetail].[ProductDetailId]
		INTO	#TMP_FilteredFeatureProduct	
		FROM	FeatureProductDetail WITH(NOLOCK)       
		WHERE		[FeatureProductDetail].[StartDate] > GETDATE()
		AND			IsActive = 1	
		AND			([FeatureProductDetail].[SupportedCategoryId] =  ISNULL(@FeatureProductListTypeId,0) or ISNULL(@FeatureProductListTypeId,0) = 0)
		ORDER BY 	[RowNo]                      
		OFFSET(@PageNumber - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;  


		SELECT			 [TMP_FilteredFeatureProduct].[RowNo]
						,[TMP_FilteredFeatureProduct].[TotalCount]
						,[TMP_FilteredFeatureProduct].[FeatureProductDetailId]
						,[TMP_FilteredFeatureProduct].[ProductDetailId]
						,[ProductDetail].[ProductName]
						,[ProductDetail].[ImgUploadPath] AS [ProductImgPath]
						,ISNULL([ReviewSummaryAgainstProduct].[RatingAvg],0) AS [ProductReviewRatting]
						,ISNULL([ReviewSummaryAgainstProduct].[ReviewerCount],0) AS [ProductReviewCount]
						,ISNULL([ProductDetail].[Amount],0)
						,ISNULL([CurrencyMaster].[CurrencySymbol],'$') AS [Currency]
		FROM		#TMP_FilteredFeatureProduct TMP_FilteredFeatureProduct
		JOIN		[ProductDetail] WITH(NOLOCK)
		ON				[TMP_FilteredFeatureProduct].[ProductDetailId] = [ProductDetail]..[ProductDetailId]
		LEFT JOIN	[ReviewSummaryAgainstProduct] WITH(NOLOCK)
		ON				[TMP_FilteredFeatureProduct].[ProductDetailId] = [ReviewSummaryAgainstProduct]..[ProductDetailId] 
		LEFT JOIN	[CurrencyMaster]
		ON				[ProductDetail].[AmountCurrencyId] = [CurrencyMaster]..[CurrencyMasterID] 

		IF OBJECT_ID('tempdb..#TMP_FilteredFeatureProduct') IS NOT NULL 
		BEGIN
			DROP TABLE #TMP_FilteredFeatureProduct
		END  

END
GO  
         